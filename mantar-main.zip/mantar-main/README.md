# mantar
mantar tanımlayıcı
