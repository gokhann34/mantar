const $ = (id) => document.getElementById(id);
const DB_NAME = 'mantar-dedektifi-db';
const DB_VERSION = 1;
let db;
let pendingFiles = [];
let pendingAnalysis = null;
let pendingLocation = null;
let records = [];
let mapInstance = null;
let mapMarkers = [];
let toastTimer;

function toast(message) {
  const el = $('toast'); el.textContent = message; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}
function esc(value='') { return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => req.result.createObjectStore('records', { keyPath: 'id' });
    req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error);
  });
}
function tx(mode='readonly') { return db.transaction('records', mode).objectStore('records'); }
function dbGetAll() { return new Promise((resolve,reject)=>{const r=tx().getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);}); }
function dbPut(value) { return new Promise((resolve,reject)=>{const r=tx('readwrite').put(value);r.onsuccess=()=>resolve();r.onerror=()=>reject(r.error);}); }
function dbDelete(id) { return new Promise((resolve,reject)=>{const r=tx('readwrite').delete(id);r.onsuccess=()=>resolve();r.onerror=()=>reject(r.error);}); }
function dateLabel(value) { return new Intl.DateTimeFormat('tr-TR',{dateStyle:'medium',timeStyle:'short'}).format(new Date(value)); }
function firstName(record) { return record.analysis?.candidates?.[0]?.common_name || 'Tanımlanamayan örnek'; }
function fileToBlob(file) { return file.slice(0, file.size, file.type); }

async function checkSession(){
  try{const r=await fetch('/api/session');const s=await r.json();if(s.passwordRequired&&!s.authenticated)$('loginOverlay').classList.remove('hidden');}
  catch{$('loginOverlay').classList.add('hidden');}
}
$('loginForm').addEventListener('submit',async e=>{
  e.preventDefault();$('loginError').textContent='';
  try{const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('appPassword').value})});const data=await r.json();if(!r.ok)throw new Error(data.error||'Giriş başarısız.');$('loginOverlay').classList.add('hidden');$('appPassword').value='';toast('Giriş yapıldı.');}
  catch(err){$('loginError').textContent=err.message;}
});

function switchTab(tab) {
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
  ['analyze','map','records'].forEach(name=>$(name+'View').classList.toggle('hidden',name!==tab));
  if(tab==='map') setTimeout(renderMap,80);
  if(tab==='records') renderRecords();
}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));

function addFiles(list) {
  const incoming = [...list];
  for (const file of incoming) {
    if (!file.type.startsWith('image/')) continue;
    if (pendingFiles.length >= 5) { toast('En fazla 5 fotoğraf ekleyebilirsin.'); break; }
    if (file.size > 8*1024*1024) { toast(`${file.name}: 8 MB sınırını aşıyor.`); continue; }
    if (!['image/jpeg','image/png','image/webp','image/heic','image/heif'].includes(file.type)) { toast('JPG, PNG, WebP veya iPhone HEIC/HEIF fotoğrafı kullan.'); continue; }
    pendingFiles.push(file);
  }
  renderPhotoGrid();
}
$('galleryInput').addEventListener('change', e=>{addFiles(e.target.files);e.target.value='';});
$('cameraInput').addEventListener('change', e=>{addFiles(e.target.files);e.target.value='';});
function renderPhotoGrid() {
  $('photoCount').textContent=pendingFiles.length;
  $('photoGrid').innerHTML='';
  if(!pendingFiles.length){$('photoGrid').innerHTML='<div class="empty-photo"><span>＋</span><b>Fotoğraf bekleniyor</b><small>En az iki farklı açı ekle</small></div>';}
  pendingFiles.forEach((file,i)=>{
    const url=URL.createObjectURL(file);
    const tile=document.createElement('div');tile.className='photo-tile';
    tile.innerHTML=`<img alt="Mantar fotoğrafı ${i+1}" src="${url}"><span class="photo-index">${i+1}</span><button class="remove-photo" aria-label="Fotoğrafı sil">×</button>`;
    tile.querySelector('button').addEventListener('click',()=>{pendingFiles.splice(i,1);renderPhotoGrid();});
    $('photoGrid').append(tile);
  });
  const ready=pendingFiles.length>=2;
  $('analyzeBtn').disabled=!ready;
  $('analysisHint').textContent=ready?'Analiz için hazır. GPS koordinatları fotoğraf analizine gönderilmez.':'Devam etmek için en az 2 fotoğraf ekle.';
}

$('getLocationBtn').addEventListener('click',()=>{
  if(!navigator.geolocation){toast('Bu tarayıcı konum özelliğini desteklemiyor.');return;}
  $('getLocationBtn').disabled=true;$('getLocationBtn').textContent='Alınıyor…';
  navigator.geolocation.getCurrentPosition(pos=>{
    pendingLocation={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy};
    $('locationTitle').textContent='Konum hazır';
    $('locationText').textContent=`Yaklaşık doğruluk: ${Math.round(pos.coords.accuracy)} m · Yalnızca bu telefonda saklanır.`;
    $('getLocationBtn').textContent='Konumu yenile';$('getLocationBtn').disabled=false;
    toast('Konum bu keşfe eklenecek.');
  },err=>{
    const reason=err.code===1?'Konum izni verilmedi.':err.code===2?'Konum bulunamadı.':'Konum isteği zaman aşımına uğradı.';
    toast(reason);$('getLocationBtn').disabled=false;$('getLocationBtn').textContent='Tekrar dene';
  },{enableHighAccuracy:true,timeout:15000,maximumAge:30000});
});

function selectedSource(){return document.querySelector('input[name="source"]:checked')?.value||'wild';}
document.querySelectorAll('input[name="source"]').forEach(input=>input.addEventListener('change',()=>{
  document.querySelectorAll('.source-choice').forEach(el=>el.classList.toggle('selected',el.querySelector('input').checked));
}));

$('analyzeBtn').addEventListener('click', analyze);
async function analyze(){
  if(pendingFiles.length<2){toast('En az 2 fotoğraf gerekiyor.');return;}
  const fd=new FormData();pendingFiles.forEach(file=>fd.append('photos',file,file.name));fd.append('source',selectedSource());
  $('loading').classList.remove('hidden');$('resultPanel').classList.add('hidden');$('analyzeBtn').disabled=true;
  try{
    const response=await fetch('/api/analyze',{method:'POST',body:fd});
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||'Analiz başarısız.');
    pendingAnalysis=data.result;renderResult(data.result);
    $('resultPanel').classList.remove('hidden');
    $('resultPanel').scrollIntoView({behavior:'smooth',block:'start'});
  }catch(err){toast(err.message||'Bağlantı hatası.');}
  finally{$('loading').classList.add('hidden');$('analyzeBtn').disabled=pendingFiles.length<2;}
}
function renderResult(result){
  const candidates=result.candidates||[];
  const candidatesHtml=candidates.length?candidates.map(c=>`<div class="candidate"><b>${esc(c.common_name||'Olası tür belirtilmedi')}</b><em>${esc(c.scientific_name||'Bilimsel ad belirsiz')} · Güven: ${esc(c.confidence||'low')}</em><p>${(c.reasons||[]).map(esc).join(' · ')}</p>${(c.lookalikes||[]).length?`<p><strong>Benzer türler:</strong> ${(c.lookalikes||[]).map(esc).join(', ')}</p>`:''}</div>`).join(''):'<p class="microcopy">Fotoğraflardan güvenilir bir tür adayı çıkarılamadı.</p>';
  const f=result.visible_features||{};
  const features=[['Şapka',f.cap],['Alt yüzey',f.underside],['Sap',f.stem],['Taban',f.base],['Habitat ipuçları',f.habitat_clues]].filter(x=>x[1]);
  $('resultPanel').innerHTML=`<div class="result-head"><span>FOTOĞRAFLI ÖN İNCELEME</span><h3>${result.is_mushroom?'Mantar örneği incelendi':'Mantar olduğu doğrulanamadı'}</h3><p>${esc(result.summary||'Fotoğraflar incelendi; sonuçlar kesin teşhis değildir.')}</p></div><div class="result-body"><h4>Olası türler</h4>${candidatesHtml}${features.length?`<h4>Görülebilen özellikler</h4><ul class="feature-list">${features.map(([k,v])=>`<li><b>${esc(k)}:</b> ${esc(v)}</li>`).join('')}</ul>`:''}${(result.missing_views||[]).length?`<h4>Eksik fotoğraf açıları</h4><ul class="feature-list">${result.missing_views.map(v=>`<li>${esc(v)}</li>`).join('')}</ul>`:''}<div class="safety-lock"><b>⚠ TÜKETİM ONAYI VERİLMEDİ</b><br>Bu uygulama yabani mantarlara yenilebilir onayı vermez. Tahmin ne kadar yüksek görünürse görünsün mantarı tüketme. Uzman doğrulaması gereklidir.${(result.risk_notes||[]).length?`<br><br>${result.risk_notes.map(esc).join('<br>')}`:''}</div>${selectedSource()==='packaged'?`<h4>Kültür mantarı için genel tarif</h4><div class="candidate"><b>Sarımsaklı tereyağında sote</b><p>Yalnızca ambalajlı, marketten alınmış kültür mantarı için: mantarı temizle ve dilimle. Tavada tereyağıyla yüksek ateşte suyunu salıp çekene kadar sotele. Sarımsak, tuz, karabiber ve maydanoz ekle; iyice pişir.</p></div>`:''}<div class="result-actions"><button id="saveRecordBtn" class="button primary">Keşfi kaydet</button><button id="newAnalysisBtn" class="button secondary">Yeni analiz</button></div></div>`;
  $('saveRecordBtn').addEventListener('click',saveRecord);$('newAnalysisBtn').addEventListener('click',()=>{$('resultPanel').classList.add('hidden');pendingAnalysis=null;pendingFiles=[];pendingLocation=null;$('locationTitle').textContent='Konum eklenmedi';$('locationText').textContent='GPS yalnızca sen istediğinde alınır ve analiz servisine gönderilmez.';$('getLocationBtn').textContent='Konum ekle';renderPhotoGrid();window.scrollTo({top:0,behavior:'smooth'});});
}

async function saveRecord(){
  if(!pendingAnalysis){toast('Önce fotoğraf analizi yapmalısın.');return;}
  const record={id:crypto.randomUUID(),createdAt:new Date().toISOString(),source:selectedSource(),analysis:pendingAnalysis,photos:pendingFiles.map(fileToBlob),location:pendingLocation?{...pendingLocation}:null};
  try{await dbPut(record);records=await dbGetAll();updateCounts();renderRecords();toast('Keşif bu telefona kaydedildi.');switchTab('records');}
  catch{toast('Kayıt saklanamadı. iPhone depolama alanını kontrol et.');}
}

function recordCard(record){
  const img=record.photos?.[0]?URL.createObjectURL(record.photos[0]):'';
  const card=document.createElement('article');card.className='record-card';
  const loc=record.location?'Konum kayıtlı':'Konum yok';
  card.innerHTML=`<img class="record-thumb" alt="Keşif fotoğrafı" src="${img}"><div class="record-main"><b>${esc(firstName(record))}</b><small>${dateLabel(record.createdAt)} · ${loc}</small><span class="record-chip">${record.source==='packaged'?'Kültür mantarı':'Yabani örnek · tüketim onayı yok'}</span></div><div class="record-actions"><button class="tiny-action open-record">Aç</button><button class="tiny-action share-record">Paylaş</button></div>`;
  card.querySelector('.open-record').addEventListener('click',()=>showDetail(record.id));
  card.querySelector('.share-record').addEventListener('click',()=>shareLocation(record.id));
  return card;
}
function renderRecords(){
  const query=($('recordSearch')?.value||'').trim().toLocaleLowerCase('tr-TR');
  const filter=$('speciesFilter')?.value||'all';
  const species=[...new Set(records.map(firstName))].sort((a,b)=>a.localeCompare(b,'tr'));
  const sel=$('speciesFilter');if(sel){const prior=sel.value;sel.innerHTML='<option value="all">Tüm türler</option>'+species.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');if(species.includes(prior))sel.value=prior;}
  const filtered=records.filter(r=>{
    const text=[firstName(r),r.analysis?.summary,r.analysis?.candidates?.[0]?.scientific_name].join(' ').toLocaleLowerCase('tr-TR');
    return (!query||text.includes(query))&&(filter==='all'||firstName(r)===filter);
  }).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  $('recordsList').innerHTML='';
  if(!filtered.length){$('recordsList').innerHTML='<div class="empty-state panel"><span>🍄</span><b>Gösterilecek keşif yok</b><small>Filtreyi değiştir veya yeni kayıt ekle.</small></div>';}
  filtered.forEach(r=>$('recordsList').append(recordCard(r)));
  $('recordsTotal').textContent=`${records.length} kayıt`;
}
$('recordSearch').addEventListener('input',renderRecords);$('speciesFilter').addEventListener('change',renderRecords);

function showDetail(id){
  const r=records.find(x=>x.id===id);if(!r)return;
  const photoHtml=(r.photos||[]).map(blob=>`<img src="${URL.createObjectURL(blob)}" alt="Mantar fotoğrafı">`).join('');
  const candidates=(r.analysis?.candidates||[]).map(c=>`<p><b>${esc(c.common_name)}</b> <em>${esc(c.scientific_name)}</em></p>`).join('');
  $('detailContent').innerHTML=`<div class="detail-photos">${photoHtml}</div><h3>${esc(firstName(r))}</h3><p class="detail-meta">${dateLabel(r.createdAt)} · ${r.source==='packaged'?'Paketli kültür mantarı':'Doğadan toplanmış yabani örnek'}</p><p class="detail-meta">${esc(r.analysis?.summary||'')}</p>${candidates}<div class="safety-lock">Bu uygulama tüketim güvenliği onayı vermez. Yabani mantarı tüketme.</div>${r.location?`<p class="detail-meta">Konum kayıtlı · ${r.location.lat.toFixed(5)}, ${r.location.lon.toFixed(5)}</p>`:'<p class="detail-meta">Bu kayıtta konum yok.</p>'}<div class="detail-buttons">${r.location?'<button id="detailShare" class="button primary">Konumu paylaş</button>':''}<button id="detailDelete" class="button secondary">Kaydı sil</button></div>`;
  if(r.location)$('detailShare').addEventListener('click',()=>shareLocation(id));
  $('detailDelete').addEventListener('click',async()=>{if(confirm('Bu keşif kaydını ve fotoğraflarını bu cihazdan silmek istiyor musun?')){await dbDelete(id);records=await dbGetAll();updateCounts();renderRecords();renderMap();$('detailDialog').close();toast('Kayıt silindi.');}});
  $('detailDialog').showModal();
}
$('closeDialog').addEventListener('click',()=>$('detailDialog').close());
async function shareLocation(id){
  const r=records.find(x=>x.id===id);if(!r?.location){toast('Bu kayıtta konum bulunmuyor.');return;}
  const {lat,lon}=r.location;
  const url=`https://maps.apple.com/?ll=${lat},${lon}&q=${encodeURIComponent(firstName(r))}`;
  const text=`Mantar keşfi: ${firstName(r)}\nTarih: ${dateLabel(r.createdAt)}\nKonum: ${lat.toFixed(6)}, ${lon.toFixed(6)}\nHarita: ${url}\nNot: Bu tür tahmini kesin teşhis veya tüketim onayı değildir.`;
  try{if(navigator.share){await navigator.share({title:'Mantar keşif konumu',text,url});}else if(navigator.clipboard){await navigator.clipboard.writeText(text);toast('Konum bağlantısı panoya kopyalandı.');}else{window.prompt('Konum paylaşım metni',text);}}catch(err){if(err.name!=='AbortError')toast('Paylaşım açılamadı.');}
}

function updateCounts(){
  $('recordCount').textContent=records.length;$('mapCount').textContent=`${records.filter(r=>r.location).length} nokta`;
  $('recordsTotal').textContent=`${records.length} kayıt`;
}
function renderMap(){
  const withLocation=records.filter(r=>r.location);
  $('mapCount').textContent=`${withLocation.length} nokta`;
  if(!window.L){$('map').innerHTML='<div class="map-empty">Harita yüklenemedi. İnternet bağlantısını kontrol et.</div>';return;}
  if(!mapInstance){mapInstance=L.map('map',{scrollWheelZoom:false}).setView([39,35],5);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(mapInstance);}
  mapMarkers.forEach(m=>mapInstance.removeLayer(m));mapMarkers=[];
  $('mapList').innerHTML='';
  if(!withLocation.length){mapInstance.setView([39,35],5);$('mapList').innerHTML='<div class="empty-state panel"><span>⌖</span><b>Konumlu kayıt yok</b><small>Yeni keşif sırasında GPS konumunu ekle.</small></div>';return;}
  const bounds=[];
  withLocation.forEach(r=>{
    const {lat,lon}=r.location;const marker=L.marker([lat,lon]).addTo(mapInstance).bindPopup(`<b>${esc(firstName(r))}</b><br>${dateLabel(r.createdAt)}`);mapMarkers.push(marker);bounds.push([lat,lon]);
    $('mapList').append(recordCard(r));
  });
  if(bounds.length===1)mapInstance.setView(bounds[0],14);else mapInstance.fitBounds(bounds,{padding:[25,25],maxZoom:13});
  setTimeout(()=>mapInstance.invalidateSize(),100);
}

$('installHint').addEventListener('click',()=>toast('Safari’de Paylaş düğmesine dokun → “Ana Ekrana Ekle” seç.'));
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/service-worker.js').catch(()=>{}));

(async()=>{
  checkSession();
  try{db=await openDB();records=await dbGetAll();records.sort((a,b)=>b.createdAt.localeCompare(a.createdAt));updateCounts();renderRecords();}
  catch{toast('Cihaz içi kayıt alanı açılamadı.');}
  renderPhotoGrid();
})();
